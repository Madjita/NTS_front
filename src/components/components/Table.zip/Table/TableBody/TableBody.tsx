import React from 'react';
import './TableBody.css'

import TableRow from '../TableColumn/TableRow/TableRow';

import {ITableData} from '../TableInterface/TableInterface'
import TableColumn from '../TableColumn/TableColumn';



type Props = {
    children?: ITableData,
}
  

const TableBody:  React.FC<Props> = ({children}) => {

    let rows =  children?.lines.map((elementRow)=>{
       let columns = elementRow.cells.map((elementColumn)=>{
            return elementColumn
       })

       return <TableRow  children={columns}/>
    })

    return(
            <tbody className='TableTbody'>
                {rows}
            </tbody>
    )
}

export default TableBody;