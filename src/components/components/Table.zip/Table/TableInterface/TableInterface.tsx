
export interface ITableData{
    headers: Array<string>,
    lines:   Array<ITableDataLines>
}

export interface ITableDataLines{
    cells: Array<string>
}
