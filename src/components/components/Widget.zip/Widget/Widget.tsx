import React, { useState } from 'react';
import './Widget.css'

type Props = {
    children: React.ReactNode,
    header?: React.ReactNode,
    className?: string
}
  

interface IProject{
    name : string
}

interface IUser {
    firstName: string,
    lastName: string,
    patronymic : string,
    email: string,
    projects: Array<IProject>,
    company: string
}


 
const Widget:  React.FC<Props> = ({header,children,className}) => {


    const [userList, setUserList] = useState<Array<IUser>>(
        [
            {
                firstName: 'Sergei',
                lastName: 'Smogliuk',
                patronymic: 'Yurivech',
                email: 'xok',
                projects: [],
                company: 'NTS'
            },
            {
                firstName: 'Dmitr',
                lastName: 'Dmitr',
                patronymic: 'Dmitr',
                email: 'Dmitr',
                projects: [],
                company: 'NTS'
            },
        ]
    )

    const [projectList, setProjectList] = useState<Array<IProject>>(
        [
            {
                name: 'Project_1'
            },
            {
                name: 'Project_2'
            },
        ]
    )


    const handleAddProject = (NewName: string) => {
        projectList.push({name:NewName})
        setProjectList(projectList)
    }

    const handleDeleteProject = (NewName: string) => {

        projectList.pop();
        setProjectList(projectList)
    }


    let newClassName = ('widget ' + className) as string;

   /* let list = Array<IUser>()
    list.push({
        firstName: 'Sergei',
        lastName: 'Smogliuk',
        patronymic: 'Yurivech',
        email: 'xok',
        projects: [],
        company: 'NTS'
    })

    list.push({
        firstName: 'Dmitr',
        lastName: 'Dmitr',
        patronymic: 'Dmitr',
        email: 'Dmitr',
        projects: [],
        company: 'NTS'
    })


    let listProject = Array<IProject>()
    listProject.push({name: 'Project_1'});
    listProject.push({name: 'Project_2'});
    */

   

    return(
            <div className={newClassName}>

               {
                    header ? 
                    <div className='header'>
                         {header}
                    </div>
                    : null
               }

               <div>
                    {children}
               </div>
            </div>
    )
}

export default Widget;